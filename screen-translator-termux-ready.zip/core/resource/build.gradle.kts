plugins {
    id("com.vamsi3.android.screentranslator.gradle.plugin.android-library")
}

android {
    namespace = "com.vamsi3.android.screentranslator.core.resource"
}
