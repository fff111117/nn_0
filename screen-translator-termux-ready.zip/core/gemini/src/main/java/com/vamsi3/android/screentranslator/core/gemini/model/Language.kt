package com.vamsi3.android.screentranslator.core.gemini.model

/**
 * نموذج يمثل لغة مدعومة للترجمة
 */
data class Language(
    val code: String,
    val name: String,
    val nativeName: String
)

/**
 * قائمة اللغات المدعومة للترجمة
 */
object SupportedLanguages {
    val languages = listOf(
        Language("ar", "Arabic", "العربية"),
        Language("en", "English", "English"),
        Language("fr", "French", "Français"),
        Language("de", "German", "Deutsch"),
        Language("es", "Spanish", "Español"),
        Language("it", "Italian", "Italiano"),
        Language("ja", "Japanese", "日本語"),
        Language("ko", "Korean", "한국어"),
        Language("nl", "Dutch", "Nederlands"),
        Language("pt", "Portuguese", "Português"),
        Language("ru", "Russian", "Русский"),
        Language("zh", "Chinese", "中文"),
        Language("tr", "Turkish", "Türkçe"),
        Language("pl", "Polish", "Polski"),
        Language("uk", "Ukrainian", "Українська"),
        Language("hi", "Hindi", "हिन्दी"),
        Language("bn", "Bengali", "বাংলা"),
        Language("ur", "Urdu", "اردو"),
        Language("fa", "Persian", "فارسی"),
        Language("sv", "Swedish", "Svenska"),
        Language("no", "Norwegian", "Norsk"),
        Language("da", "Danish", "Dansk"),
        Language("fi", "Finnish", "Suomi"),
        Language("el", "Greek", "Ελληνικά"),
        Language("cs", "Czech", "Čeština"),
        Language("hu", "Hungarian", "Magyar"),
        Language("ro", "Romanian", "Română"),
        Language("th", "Thai", "ไทย"),
        Language("vi", "Vietnamese", "Tiếng Việt"),
        Language("id", "Indonesian", "Bahasa Indonesia"),
        Language("ms", "Malay", "Bahasa Melayu"),
        Language("he", "Hebrew", "עברית"),
        Language("bg", "Bulgarian", "Български"),
        Language("hr", "Croatian", "Hrvatski"),
        Language("sr", "Serbian", "Српски"),
        Language("sk", "Slovak", "Slovenčina"),
        Language("sl", "Slovenian", "Slovenščina"),
        Language("et", "Estonian", "Eesti"),
        Language("lv", "Latvian", "Latviešu"),
        Language("lt", "Lithuanian", "Lietuvių"),
        Language("af", "Afrikaans", "Afrikaans"),
        Language("sw", "Swahili", "Kiswahili"),
        Language("am", "Amharic", "አማርኛ"),
        Language("hy", "Armenian", "Հայերեն"),
        Language("az", "Azerbaijani", "Azərbaycan"),
        Language("eu", "Basque", "Euskara"),
        Language("be", "Belarusian", "Беларуская"),
        Language("ca", "Catalan", "Català"),
        Language("gl", "Galician", "Galego"),
        Language("ka", "Georgian", "ქართული"),
        Language("is", "Icelandic", "Íslenska"),
        Language("kk", "Kazakh", "Қазақ"),
        Language("km", "Khmer", "ខ្មែរ"),
        Language("lo", "Lao", "ລາວ"),
        Language("mk", "Macedonian", "Македонски"),
        Language("mn", "Mongolian", "Монгол"),
        Language("my", "Myanmar", "မြန်မာ"),
        Language("ne", "Nepali", "नेपाली"),
        Language("si", "Sinhala", "සිංහල"),
        Language("tl", "Tagalog", "Tagalog"),
        Language("ta", "Tamil", "தமிழ்"),
        Language("te", "Telugu", "తెలుగు"),
        Language("uz", "Uzbek", "O'zbek")
    )
    
    /**
     * الحصول على لغة من خلال رمزها
     */
    fun getLanguageByCode(code: String): Language? {
        return languages.find { it.code == code }
    }
    
    /**
     * البحث عن لغات بناءً على نص البحث
     */
    fun searchLanguages(query: String): List<Language> {
        if (query.isEmpty()) return languages
        
        val lowerQuery = query.lowercase()
        return languages.filter { 
            it.name.lowercase().contains(lowerQuery) || 
            it.nativeName.lowercase().contains(lowerQuery) ||
            it.code.lowercase().contains(lowerQuery)
        }
    }
}
