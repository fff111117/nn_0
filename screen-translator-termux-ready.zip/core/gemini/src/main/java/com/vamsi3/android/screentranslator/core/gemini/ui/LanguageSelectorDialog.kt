package com.vamsi3.android.screentranslator.core.gemini.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vamsi3.android.screentranslator.core.gemini.model.Language
import com.vamsi3.android.screentranslator.core.gemini.model.SupportedLanguages
import com.vamsi3.android.screentranslator.core.resource.R

/**
 * محول قائمة اللغات
 */
class LanguageAdapter(
    private val context: Context,
    private var languages: List<Language>,
    private val onLanguageSelected: (Language) -> Unit
) : RecyclerView.Adapter<LanguageAdapter.LanguageViewHolder>() {

    class LanguageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val languageName: TextView = view.findViewById(R.id.language_name)
        val languageNativeName: TextView = view.findViewById(R.id.language_native_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LanguageViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_language, parent, false)
        return LanguageViewHolder(view)
    }

    override fun onBindViewHolder(holder: LanguageViewHolder, position: Int) {
        val language = languages[position]
        holder.languageName.text = language.name
        holder.languageNativeName.text = language.nativeName
        
        holder.itemView.setOnClickListener {
            onLanguageSelected(language)
        }
    }

    override fun getItemCount(): Int = languages.size
    
    /**
     * تحديث قائمة اللغات بناءً على نص البحث
     */
    fun updateLanguages(query: String) {
        languages = SupportedLanguages.searchLanguages(query)
        notifyDataSetChanged()
    }
}

/**
 * نافذة منبثقة لاختيار اللغة
 */
class LanguageSelectorDialog(
    private val context: Context,
    private val title: String,
    private val onLanguageSelected: (Language) -> Unit
) {
    private val dialog: Dialog = Dialog(context)
    private lateinit var adapter: LanguageAdapter
    
    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setGravity(android.view.Gravity.CENTER)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_language_selector)
        
        // تعيين العنوان
        val titleTextView = dialog.findViewById<TextView>(R.id.language_selector_title)
        titleTextView.text = title
        
        // إعداد قائمة اللغات
        val recyclerView = dialog.findViewById<RecyclerView>(R.id.language_list)
        recyclerView.layoutManager = LinearLayoutManager(context)
        
        adapter = LanguageAdapter(context, SupportedLanguages.languages) { language ->
            onLanguageSelected(language)
            dialog.dismiss()
        }
        
        recyclerView.adapter = adapter
        
        // إعداد حقل البحث
        val searchEditText = dialog.findViewById<EditText>(R.id.language_search)
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.updateLanguages(s.toString())
            }
            
            override fun afterTextChanged(s: Editable?) {}
        })
        
        // إعداد زر الإلغاء
        val cancelButton = dialog.findViewById<Button>(R.id.cancel_button)
        cancelButton.setOnClickListener {
            dialog.dismiss()
        }
    }
    
    /**
     * عرض نافذة اختيار اللغة
     */
    fun show() {
        dialog.show()
    }
}
