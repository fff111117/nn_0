package com.vamsi3.android.screentranslator.core.gemini.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.vamsi3.android.screentranslator.core.gemini.GeminiTranslationService
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object GeminiModule {
    
    @Provides
    @Singleton
    fun provideGeminiTranslationService(): GeminiTranslationService {
        return GeminiTranslationService()
    }
}
