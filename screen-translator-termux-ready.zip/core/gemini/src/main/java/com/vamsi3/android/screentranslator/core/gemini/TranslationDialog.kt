package com.vamsi3.android.screentranslator.core.gemini

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.vamsi3.android.screentranslator.core.gemini.model.Language
import com.vamsi3.android.screentranslator.core.gemini.model.SupportedLanguages
import com.vamsi3.android.screentranslator.core.gemini.ui.LanguageSelectorDialog
import com.vamsi3.android.screentranslator.core.resource.R

/**
 * نافذة منبثقة لعرض الترجمة
 */
class TranslationDialog(private val context: Context) {
    
    private val dialog: Dialog = Dialog(context)
    private var sourceLanguage: Language = SupportedLanguages.getLanguageByCode("en") ?: SupportedLanguages.languages[0]
    private var targetLanguage: Language = SupportedLanguages.getLanguageByCode("ar") ?: SupportedLanguages.languages[1]
    private var translatedText: String = ""
    private var onLanguageChangedListener: ((String, String) -> Unit)? = null
    
    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setGravity(Gravity.CENTER)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.setCancelable(true)
    }
    
    /**
     * تعيين مستمع لتغيير اللغة
     */
    fun setOnLanguageChangedListener(listener: (sourceLanguageCode: String, targetLanguageCode: String) -> Unit) {
        onLanguageChangedListener = listener
    }
    
    /**
     * عرض الترجمة في نافذة منبثقة
     * 
     * @param translatedText النص المترجم
     */
    fun showTranslation(translatedText: String) {
        this.translatedText = translatedText
        
        // إنشاء تخطيط للنافذة المنبثقة
        dialog.setContentView(R.layout.dialog_translation)
        
        // تعيين النص المترجم
        val textView = dialog.findViewById<TextView>(R.id.translation_text)
        textView.text = translatedText
        
        // إعداد أزرار اللغات
        setupLanguageButtons()
        
        // زر النسخ
        val copyButton = dialog.findViewById<Button>(R.id.copy_button)
        copyButton.setOnClickListener {
            copyToClipboard(translatedText)
        }
        
        // زر الإغلاق
        val closeButton = dialog.findViewById<Button>(R.id.close_button)
        closeButton.setOnClickListener {
            dialog.dismiss()
        }
        
        // عرض النافذة المنبثقة
        dialog.show()
    }
    
    /**
     * إعداد أزرار اختيار اللغات
     */
    private fun setupLanguageButtons() {
        // زر اللغة المصدر
        val sourceLanguageButton = dialog.findViewById<Button>(R.id.source_language_button)
        sourceLanguageButton.text = sourceLanguage.name
        sourceLanguageButton.setOnClickListener {
            showLanguageSelector("اختر اللغة المصدر") { language ->
                sourceLanguage = language
                sourceLanguageButton.text = language.name
                notifyLanguageChanged()
            }
        }
        
        // زر اللغة الهدف
        val targetLanguageButton = dialog.findViewById<Button>(R.id.target_language_button)
        targetLanguageButton.text = targetLanguage.name
        targetLanguageButton.setOnClickListener {
            showLanguageSelector("اختر اللغة الهدف") { language ->
                targetLanguage = language
                targetLanguageButton.text = language.name
                notifyLanguageChanged()
            }
        }
        
        // زر تبديل اللغات
        val swapLanguagesButton = dialog.findViewById<ImageView>(R.id.swap_languages_button)
        swapLanguagesButton.setOnClickListener {
            val tempLanguage = sourceLanguage
            sourceLanguage = targetLanguage
            targetLanguage = tempLanguage
            
            sourceLanguageButton.text = sourceLanguage.name
            targetLanguageButton.text = targetLanguage.name
            
            notifyLanguageChanged()
        }
    }
    
    /**
     * عرض نافذة اختيار اللغة
     */
    private fun showLanguageSelector(title: String, onLanguageSelected: (Language) -> Unit) {
        val languageSelectorDialog = LanguageSelectorDialog(context, title, onLanguageSelected)
        languageSelectorDialog.show()
    }
    
    /**
     * إشعار بتغيير اللغة
     */
    private fun notifyLanguageChanged() {
        onLanguageChangedListener?.invoke(sourceLanguage.code, targetLanguage.code)
    }
    
    /**
     * نسخ النص إلى الحافظة
     */
    private fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Translated Text", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "تم نسخ النص", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * الحصول على رمز اللغة المصدر
     */
    fun getSourceLanguageCode(): String {
        return sourceLanguage.code
    }
    
    /**
     * الحصول على رمز اللغة الهدف
     */
    fun getTargetLanguageCode(): String {
        return targetLanguage.code
    }
    
    /**
     * إغلاق النافذة المنبثقة
     */
    fun dismiss() {
        dialog.dismiss()
    }
}
