package com.vamsi3.android.screentranslator.core.gemini

import android.graphics.Bitmap
import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.vamsi3.android.screentranslator.core.gemini.model.Language
import com.vamsi3.android.screentranslator.core.gemini.model.SupportedLanguages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeminiTranslationService @Inject constructor() {
    
    private val apiKey = "AIzaSyApHVTM66dPMKOim4s8uyDYNP8aZDH7_qo"
    
    private val generativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-pro-vision",
            apiKey = apiKey
        )
    }
    
    /**
     * ترجمة النص المستخرج من الصورة بين لغتين
     * 
     * @param bitmap صورة الشاشة التي تحتوي على النص
     * @param sourceLanguageCode رمز اللغة المصدر
     * @param targetLanguageCode رمز اللغة الهدف
     * @return النص المترجم
     */
    suspend fun translateScreenshot(
        bitmap: Bitmap,
        sourceLanguageCode: String = "en",
        targetLanguageCode: String = "ar"
    ): String = withContext(Dispatchers.IO) {
        try {
            val sourceLanguage = SupportedLanguages.getLanguageByCode(sourceLanguageCode)
                ?: SupportedLanguages.getLanguageByCode("en")
                ?: SupportedLanguages.languages[0]
                
            val targetLanguage = SupportedLanguages.getLanguageByCode(targetLanguageCode)
                ?: SupportedLanguages.getLanguageByCode("ar")
                ?: SupportedLanguages.languages[1]
            
            val prompt = buildTranslationPrompt(sourceLanguage, targetLanguage)
            
            val inputContent = content {
                text(prompt)
                image(bitmap)
            }
            
            val response = generativeModel.generateContent(inputContent)
            
            return@withContext response.text ?: "فشلت الترجمة. يرجى المحاولة مرة أخرى."
        } catch (e: Exception) {
            Log.e("GeminiTranslationService", "Error translating screenshot", e)
            return@withContext "حدث خطأ أثناء الترجمة: ${e.message}"
        }
    }
    
    /**
     * بناء نص الطلب للترجمة بين لغتين
     * 
     * @param sourceLanguage اللغة المصدر
     * @param targetLanguage اللغة الهدف
     * @return نص الطلب
     */
    private fun buildTranslationPrompt(sourceLanguage: Language, targetLanguage: Language): String {
        return "أنت مترجم محترف متخصص في الترجمة الدقيقة والطبيعية. مهمتك هي ترجمة النص الموجود في الصورة المرفقة.\n\n" +
                "اللغة المصدر: ${sourceLanguage.name} (${sourceLanguage.nativeName})\n" +
                "اللغة الهدف: ${targetLanguage.name} (${targetLanguage.nativeName})\n\n" +
                "إرشادات الترجمة:\n" +
                "1. قم بترجمة النص من اللغة المصدر إلى اللغة الهدف بدقة عالية.\n" +
                "2. إذا كان النص بلغة مختلفة عن اللغة المصدر المحددة، فحاول تحديد اللغة الفعلية وترجمتها إلى اللغة الهدف.\n" +
                "3. حافظ على المعنى الأصلي والسياق والنبرة في الترجمة.\n" +
                "4. استخدم مصطلحات وتعبيرات طبيعية في اللغة الهدف كما لو كانت مكتوبة من قبل متحدث أصلي.\n" +
                "5. حافظ على تنسيق النص الأصلي (مثل الفقرات والقوائم) قدر الإمكان.\n" +
                "6. ترجم أي نصوص تقنية أو متخصصة بدقة مع مراعاة المصطلحات المناسبة في المجال.\n\n" +
                "قم بإرجاع النص المترجم فقط دون أي تعليقات إضافية أو شروحات أو علامات ترقيم غير موجودة في النص الأصلي."
    }
}
