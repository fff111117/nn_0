# تطبيق ترجمة الشاشة المحسن باستخدام Gemini AI

## التعديلات الرئيسية

تم تحسين تطبيق ترجمة الشاشة الأصلي بإضافة الميزات التالية:

1. **ترجمة داخلية باستخدام Gemini AI**: بدلاً من الاعتماد على تطبيقات ترجمة خارجية، يمكن الآن استخدام واجهة برمجة تطبيقات Gemini للترجمة داخل التطبيق.

2. **دعم أكثر من 60 لغة**: تمت إضافة دعم لأكثر من 60 لغة مختلفة للترجمة.

3. **واجهة اختيار اللغات**: واجهة سهلة الاستخدام لاختيار اللغة المصدر واللغة الهدف.

4. **البحث عن اللغات**: إمكانية البحث عن اللغات بالاسم أو الاسم الأصلي.

5. **تبديل اللغات**: زر لتبديل اللغة المصدر واللغة الهدف بسرعة.

6. **نسخ النص المترجم**: إمكانية نسخ النص المترجم إلى الحافظة.

## كيفية الاستخدام

1. قم بتثبيت التطبيق على جهازك.
2. افتح إعدادات الجهاز > إمكانية الوصول > وقم بتفعيل خدمة "Screen Translator".
3. افتح تطبيق Screen Translator وانتقل إلى الإعدادات.
4. اختر "Gemini AI" من قائمة تطبيقات الترجمة.
5. اسحب شريط الإشعارات لأسفل واستخدم ميزة الترجمة.
6. ستظهر نافذة منبثقة تعرض النص المترجم.
7. يمكنك تغيير اللغة المصدر واللغة الهدف من خلال الأزرار في أعلى النافذة.
8. يمكنك تبديل اللغات باستخدام زر التبديل بين اللغتين.
9. يمكنك نسخ النص المترجم باستخدام زر "نسخ".

## متطلبات النظام

- أندرويد 8.0 أو أحدث
- اتصال بالإنترنت (مطلوب لاستخدام واجهة برمجة تطبيقات Gemini)

## ملاحظات فنية

- تم استخدام مكتبة Gemini AI الرسمية (com.google.ai.client.generativeai:generativeai:0.2.0)
- تم تكوين مفتاح API الخاص بـ Gemini: AIzaSyApHVTM66dPMKOim4s8uyDYNP8aZDH7_qo
- تم تحسين نص الطلب للحصول على ترجمات أكثر دقة وطبيعية
- تم إضافة دعم للغات متعددة مع إمكانية البحث والتصفية

## الملفات المعدلة

1. **إضافة وحدة Gemini الجديدة**:
   - core/gemini/build.gradle.kts
   - core/gemini/src/main/java/com/vamsi3/android/screentranslator/core/gemini/GeminiTranslationService.kt
   - core/gemini/src/main/java/com/vamsi3/android/screentranslator/core/gemini/TranslationDialog.kt
   - core/gemini/src/main/java/com/vamsi3/android/screentranslator/core/gemini/model/Language.kt
   - core/gemini/src/main/java/com/vamsi3/android/screentranslator/core/gemini/ui/LanguageSelectorDialog.kt

2. **تعديل الملفات الموجودة**:
   - core/model/src/main/java/com/vamsi3/android/screentranslator/core/data/model/TranslateApp.kt
   - feature/translate/src/main/java/com/vamsi3/android/screentranslator/feature/translate/ScreenTranslatorAccessibilityService.kt
   - feature/translate/build.gradle.kts
   - settings.gradle.kts

3. **إضافة ملفات تخطيط جديدة**:
   - core/resource/src/main/res/layout/dialog_translation.xml
   - core/resource/src/main/res/layout/dialog_language_selector.xml
   - core/resource/src/main/res/layout/item_language.xml
   - core/resource/src/main/res/drawable/dialog_background.xml
   - core/resource/src/main/res/drawable/search_background.xml

## كيفية تجميع التطبيق

1. افتح المشروع في Android Studio.
2. قم بتحديث Gradle إذا لزم الأمر.
3. قم بتشغيل Gradle Sync لتحميل التبعيات الجديدة.
4. قم ببناء التطبيق باستخدام خيار Build > Build Bundle(s) / APK(s) > Build APK(s).
5. قم بتثبيت ملف APK الناتج على جهازك.

## استكشاف الأخطاء وإصلاحها

إذا واجهت أي مشاكل في الترجمة:

1. تأكد من وجود اتصال بالإنترنت.
2. تأكد من تفعيل خدمة إمكانية الوصول للتطبيق.
3. تحقق من سجلات التطبيق (Logcat) للحصول على معلومات التصحيح.
4. تأكد من اختيار "Gemini AI" في إعدادات التطبيق.

## الإصدارات المستقبلية

- تحسين دقة الترجمة
- إضافة خيار حفظ الترجمات السابقة
- إضافة خيار الترجمة التلقائية
- تحسين واجهة المستخدم
